"use client";

import React, { useState } from "react";
import { useDraggable } from "@dnd-kit/core";
import { getComponentDefinition } from "@/lib/components-registry";
import { ComponentData, FrameData } from "@/lib/utils";
import { ResizableBox, ResizeCallbackData, ResizeHandle } from "react-resizable";
import "react-resizable/css/styles.css";
import { Popover, PopoverTrigger } from "@/components/ui/popover";
import { ComponentPropertiesEditor } from "@/components/ComponentPropertiesEditor";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

// Selection mode interface
interface SelectionMode {
  isActive: boolean;
  type: 'input' | 'output' | 'trigger' | null;
  functionalityId: string | null;
  inputIndex?: number;
}

interface CanvasComponentProps {
  component: ComponentData;
  frames: FrameData[];
  isSelected: boolean;
  isHovered: boolean;
  onSelect: (id: string) => void;
  onResize: (id: string, size: { width: number; height: number }) => void;
  onUpdateProperties: (id: string, properties: Record<string, any>) => void;
  onHoverFrame: (id: string | null) => void;
  onDelete?: (id: string) => void;
  selectionMode?: SelectionMode;
  onComponentSelected?: (componentId: string) => void;
}

interface RenderProps {
  isInteractive: boolean;
  className: string;
  id: string;
  component?: ComponentData;
  [key: string]: any;
}

const CanvasComponent: React.FC<CanvasComponentProps> = ({
  component,
  frames,
  isSelected,
  isHovered,
  onSelect,
  onResize,
  onUpdateProperties,
  onHoverFrame,
  onDelete,
  selectionMode,
  onComponentSelected,
}) => {
  const [isPropertiesOpen, setIsPropertiesOpen] = useState(false);

  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `canvas-component-${component.id}`,
    data: {
      type: component.type,
      id: component.id,
      isCanvasComponent: true,
    },
  });

  const componentDef = getComponentDefinition(component.type);
  console.log(`🎯 CanvasComponent: Looking for component type "${component.type}"`, {
    found: !!componentDef,
    componentType: component.type,
    isAIComponent: component.type.startsWith("AI"),
    componentId: component.id
  });
  if (!componentDef) {
    console.error(`❌ CanvasComponent: No component definition found for type "${component.type}"`);
    return null;
  }

  const handleResize = (
    event: React.SyntheticEvent, 
    data: ResizeCallbackData
  ) => {
    onResize(component.id, { 
      width: data.size.width, 
      height: data.size.height 
    });
  };

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    // Handle selection mode
    if (selectionMode?.isActive && onComponentSelected) {
      // Check if this component is selectable for the current selection mode
      if (isSelectableForMode(component, selectionMode.type)) {
        onComponentSelected(component.id);
        return;
      }
    }
    
    // Normal selection behavior
    onSelect(component.id);
  };

  // Helper function to determine if a component is selectable for the current mode
  const isSelectableForMode = (component: ComponentData, selectionType: string | null): boolean => {
    const componentDef = getComponentDefinition(component.type);
    if (!componentDef) return false;

    switch (selectionType) {
      case 'input':
        return componentDef.category === "Input" ||
               component.type === "Textarea" ||
               component.type === "Input" ||
               component.type === "ImageUpload" ||
               component.type === "DataTable" ||
               component.type === "InsuranceInput" ||
               component.type === "InsuranceInsight" ||
               component.type === "AIInput" ||
               component.type.startsWith("AI");
      case 'output':
        return componentDef.category === "Output" ||
               componentDef.category === "Data Display" ||
               component.type === "TextOutput" ||
               component.type === "DataTable" ||
               component.type === "InsuranceChat" ||
               component.type === "AIOutput" ||
               component.type.startsWith("AI");
      case 'trigger':
        return component.type === "Button" ||
               component.type === "InsuranceSendButton" ||
               component.type.startsWith("AI");
      default:
        return false;
    }
  };

  // Check if component is selectable in current mode
  const isSelectableInCurrentMode = selectionMode?.isActive && 
    isSelectableForMode(component, selectionMode.type);

  // Check if component is highlighted for selection
  const isHighlightedForSelection = isSelectableInCurrentMode;

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onSelect(component.id);
    setIsPropertiesOpen(true);
  };
  
  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onDelete) {
      onDelete(component.id);
    }
  };

  // Only show resize handles when the component is selected
  const resizeHandles: ResizeHandle[] = isSelected ? ["se"] : [];

  // Check if this is an AI-generated component
  const isAIComponent = component.type.startsWith("AI");

  // Prepare render props
  const renderProps: RenderProps = {
    isInteractive: false,
    className: "relative w-full h-full",
    id: `canvas-${component.id}`,
    // Ensure properties exists before spreading
    ...(component.properties || {}),
  };

  // For AI components, pass the full component object and element positioning props
  if (isAIComponent) {
    renderProps.component = component;
    
    // Add element positioning props
    renderProps.enableElementPositioning = component.properties?.enableElementPositioning || false;
    renderProps.elementPositions = component.properties?.elementPositions || {};
    renderProps.onElementPositionChange = (elementId: string, position: { x: number; y: number }) => {
      // Update component properties with new element positions
      const updatedProperties = {
        ...component.properties,
        elementPositions: {
          ...(component.properties?.elementPositions || {}),
          [elementId]: position
        }
      };
      onUpdateProperties(component.id, updatedProperties);
    };
  }

  return (
    <div
      className="fixed"
      style={{
        left: `${component.position.x}px`,
        top: `${component.position.y}px`,
        zIndex: isDragging ? 1000 : isSelected ? 10 : isHovered ? 5 : 1,
      }}
    >
      <Popover open={isPropertiesOpen} onOpenChange={() => {}}>
        <PopoverTrigger asChild>
          <div>
            <ResizableBox
              width={component.size.width}
              height={component.size.height}
              onResizeStop={handleResize}
              minConstraints={[10, 10]} // Minimum size constraints
              maxConstraints={[800, 800]} // Maximum size constraints
              resizeHandles={resizeHandles}
            >
              <div
                ref={setNodeRef}
                {...listeners}
                {...attributes}
                className={`cursor-move transition-all duration-200 relative ${
                  isSelected ? "ring-2 ring-blue-500" : ""
                } ${
                  isHovered
                    ? "ring-2 ring-blue-400 ring-offset-2 shadow-lg"
                    : ""
                } ${
                  isHighlightedForSelection
                    ? "ring-2 ring-green-400 ring-offset-2 shadow-lg cursor-pointer"
                    : ""
                } ${
                  selectionMode?.isActive && !isSelectableInCurrentMode
                    ? "opacity-50 cursor-not-allowed"
                    : ""
                }`}
                style={{
                  width: "100%",
                  height: "100%",
                  opacity: isDragging ? 0.5 : 1,
                  transition: "all 150ms ease-in-out",
                }}
                onClick={handleClick}
                onContextMenu={handleContextMenu}
              >
                {/* Add delete button when component is selected */}
                {isSelected && onDelete && (
                  <div 
                    className="absolute -top-8 right-0 z-20"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Button 
                      variant="destructive" 
                      size="sm" 
                      className="h-7 px-2 flex items-center"
                      onClick={handleDelete}
                    >
                      <Trash2 className="h-4 w-4 mr-1" />
                      Delete
                    </Button>
                  </div>
                )}
                
                {/* Add overlay div when hovered */}
                {isHovered && (
                  <div
                    className="absolute inset-0 bg-blue-200 opacity-50 pointer-events-none z-10"
                    style={{
                      borderRadius: "inherit",
                    }}
                  />
                )}
                {componentDef.render(renderProps)}
              </div>
            </ResizableBox>
          </div>
        </PopoverTrigger>
        <ComponentPropertiesEditor
          component={component}
          frames={frames}
          onUpdateProperties={onUpdateProperties}
          onClose={() => setIsPropertiesOpen(false)}
          onHoverFrame={onHoverFrame}
        />
      </Popover>
    </div>
  );
};

export default CanvasComponent;
