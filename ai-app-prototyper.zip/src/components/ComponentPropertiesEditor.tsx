"use client";

import React from "react";
import { PopoverContent } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ComponentData, FrameData } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { X, Ban, Loader2, UploadCloud } from "lucide-react";
import { TableData } from "@/components/ui/datatable";
import Papa from "papaparse";

interface ComponentPropertiesEditorProps {
  component: ComponentData;
  frames: FrameData[];
  onUpdateProperties: (id: string, properties: Record<string, any>) => void;
  onClose: () => void;
  onHoverFrame: (id: string | null) => void;
}

// Maximum number of CSV rows to process at once
const CSV_CHUNK_SIZE = 500;

export const ComponentPropertiesEditor: React.FC<
  ComponentPropertiesEditorProps
> = ({ component, frames, onUpdateProperties, onClose, onHoverFrame }) => {
  // Get initial properties or use an empty object with default values
  const initialProperties = component.properties || {};

  // Create state for all editable properties
  const [properties, setProperties] =
    React.useState<Record<string, any>>(initialProperties);
  const [isProcessingCsv, setIsProcessingCsv] = React.useState(false);
  const [csvStats, setCsvStats] = React.useState<{
    totalRows: number;
    totalColumns: number;
  } | null>(null);

  // Handle mouse enter/leave for frame highlighting
  const handleMouseEnter = (frameId: string) => {
    onHoverFrame(frameId);
  };

  const handleMouseLeave = () => {
    onHoverFrame(null);
  };

  // Handle input changes
  const handleChange = (key: string, value: any) => {
    // Special handling for navigateTo property
    if (key === "navigateTo" && value === "none") {
      // Remove the navigateTo property entirely
      const newProperties = { ...properties };
      delete newProperties.navigateTo;
      setProperties(newProperties);
    } else {
      setProperties((prev) => ({
        ...prev,
        [key]: value,
      }));
    }
  };

  // Handle save
  const handleSave = () => {
    onUpdateProperties(component.id, properties);
    onHoverFrame(null);
    onClose();
  };

  const processCsvChunks = (
    results: Papa.ParseResult<string[]>,
    file: File,
    chunkSize: number = CSV_CHUNK_SIZE
  ) => {
    return new Promise<TableData | null>((resolve, reject) => {
      // Check for errors
      if (results.errors.length > 0) {
        console.error("PapaParse errors:", results.errors);
        const errorMessages = results.errors
          .map((err) => `${err.message} (Row: ${err.row})`)
          .join("\n");
        alert(
          `Failed to parse CSV file. Please ensure it's correctly formatted.\n${errorMessages}`
        );
        resolve(null);
        return;
      }

      const data: string[][] = results.data;

      if (!data || data.length === 0) {
        resolve(null);
        return;
      }

      // Extract and process headers
      const rawHeaders = data[0];
      if (!rawHeaders || (rawHeaders.length === 0 && data.length === 1)) {
        resolve(null);
        return;
      }

      const headers = rawHeaders.map((h, index) => {
        const headerText = (h || "").toString().trim();
        // Ensure unique headers by adding index if duplicate
        return headerText || `Column ${index + 1}`;
      });

      // Check for duplicate headers and make them unique
      const uniqueHeaders = headers.map((header, index) => {
        const duplicateCount = headers.slice(0, index).filter(h => h === header).length;
        return duplicateCount > 0 ? `${header} (${duplicateCount + 1})` : header;
      });

      const allHeadersEmpty = uniqueHeaders.every((h) => h.startsWith("Column "));

      if (allHeadersEmpty && data.length <= 1) {
        resolve(null);
        return;
      }

      // Process rows in chunks
      const rowData = data.slice(1);
      const totalRows = rowData.length;
      const processedRows: string[][] = [];
      const totalChunks = Math.ceil(totalRows / chunkSize);

      // Set stats for display
      setCsvStats({
        totalRows,
        totalColumns: uniqueHeaders.length,
      });

      // Process the first chunk immediately
      const firstChunkEnd = Math.min(chunkSize, totalRows);
      processRowChunk(0, firstChunkEnd);

      function processRowChunk(start: number, end: number) {
        const chunk = rowData.slice(start, end);

        // Process this chunk
        const processedChunk = chunk.map((rowArray) => {
          const newRow = Array(uniqueHeaders.length).fill("");
          for (let i = 0; i < uniqueHeaders.length; i++) {
            if (rowArray[i] !== undefined && rowArray[i] !== null) {
              newRow[i] = String(rowArray[i]).trim();
            }
          }
          return newRow;
        });

        // Add to processed rows
        processedRows.push(...processedChunk);

        // If we're done, resolve with the result
        if (end >= totalRows) {
          resolve({ headers: uniqueHeaders, rows: processedRows });
          return;
        }

        // Process next chunk with a small delay to avoid UI freezing
        const nextEnd = Math.min(end + chunkSize, totalRows);
        setTimeout(() => processRowChunk(end, nextEnd), 0);
      }
    });
  };

  const handleFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (!file) {
      return;
    }

    // Basic MIME type check
    if (
      !file.type.includes("csv") &&
      !file.name.toLowerCase().endsWith(".csv")
    ) {
      alert("Please upload a valid .csv file.");
      event.target.value = ""; // Reset file input
      return;
    }

    // Start loading indicator
    setIsProcessingCsv(true);
    setCsvStats(null);

    // Use worker-thread approach for larger files
    const workerEnabled = file.size > 1024 * 1024; // 1MB threshold

    if (workerEnabled) {
      Papa.parse<string[]>(file, {
        worker: true, // Use worker thread
        skipEmptyLines: true,
        complete: async (results) => {
          try {
            const tableData = await processCsvChunks(results, file);
            handleChange("data", tableData);
          } catch (error) {
            console.error("Error processing CSV:", error);
            alert("An error occurred while processing the CSV file.");
            handleChange("data", null);
          } finally {
            setIsProcessingCsv(false);
            event.target.value = ""; // Reset file input
          }
        },
        error: (error) => {
          console.error("PapaParse critical error:", error);
          alert(
            "A critical error occurred while trying to read or parse the CSV file."
          );
          handleChange("data", null);
          setIsProcessingCsv(false);
          event.target.value = "";
        },
      });
    } else {
      // For smaller files, use the regular approach
      Papa.parse<string[]>(file, {
        skipEmptyLines: true,
        complete: async (results) => {
          try {
            const tableData = await processCsvChunks(results, file);
            handleChange("data", tableData);
          } catch (error) {
            console.error("Error processing CSV:", error);
            alert("An error occurred while processing the CSV file.");
            handleChange("data", null);
          } finally {
            setIsProcessingCsv(false);
            event.target.value = ""; // Reset file input
          }
        },
        error: (error) => {
          console.error("PapaParse critical error:", error);
          alert(
            "A critical error occurred while trying to read or parse the CSV file."
          );
          handleChange("data", null);
          setIsProcessingCsv(false);
          event.target.value = "";
        },
      });
    }
  };

  const handleClearCsvData = () => {
    handleChange("data", null);
    setCsvStats(null);
  };

  // Render navigation controls
  const renderNavigationControls = () => {
    if (component.type !== "Button") return null;

    return (
      <>
        <div className="my-4 pt-4 border-t border-gray-200">
          <h3 className="font-medium mb-4">Navigation</h3>
          <div className="grid gap-2 mb-4">
            <Label htmlFor="navigate-to">Navigate to</Label>
            <Select
              onValueChange={(value) => handleChange("navigateTo", value)}
              value={properties.navigateTo || "none"}
              defaultValue="none"
            >
              <SelectTrigger id="navigate-to">
                <SelectValue placeholder="Select a frame to navigate to" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none" className="cursor-pointer hover:bg-blue-50">
                  <div className="flex items-center">
                    <Ban className="h-4 w-4 mr-2" />
                    None
                  </div>
                </SelectItem>
                {frames.filter(frame => frame.id && frame.id.trim() !== "").map((frame) => (
                  <SelectItem
                    key={frame.id}
                    value={frame.id}
                    onMouseEnter={() => handleMouseEnter(frame.id)}
                    onMouseLeave={handleMouseLeave}
                    className="cursor-pointer hover:bg-blue-50"
                  >
                    {frame.label} - {frame.id}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </>
    );
  };

  const renderTablePropertyFields = () => {
    const tableData = properties.data as TableData | null;

    return (
      <>
        <div className="grid gap-2 mb-4">
          <Label htmlFor="table-csv-upload">Upload CSV File</Label>
          <Input
            id="table-csv-upload"
            type="file"
            accept=".csv"
            onChange={handleFileUpload}
            disabled={isProcessingCsv}
            className="block w-full text-sm text-slate-500 cursor-pointer
              file:mr-3 file:py-1.5 file:px-3
              file:rounded-md file:border-0
              file:text-xs file:font-medium
              file:bg-slate-100 file:text-slate-700
              hover:file:bg-slate-200 disabled:opacity-60 disabled:cursor-not-allowed"
          />

          {isProcessingCsv && (
            <div className="mt-2 text-xs text-blue-600 p-2 border rounded-md bg-blue-50 flex items-center">
              <Loader2 className="h-3 w-3 mr-2 animate-spin" />
              <span>Processing CSV data...</span>
            </div>
          )}

          {!isProcessingCsv && tableData && tableData.headers.length > 0 && (
            <div className="mt-2 text-xs text-gray-600 p-2 border rounded-md bg-gray-50">
              <p className="font-semibold">
                Loaded: {tableData.headers.length} columns,{" "}
                {csvStats?.totalRows || tableData.rows.length} rows.
              </p>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleClearCsvData}
                className="mt-1 text-red-600 hover:text-red-700 px-1 py-0 h-auto hover:bg-red-50"
              >
                <X className="h-3 w-3 mr-1" />
                Clear Data
              </Button>
            </div>
          )}

          {!isProcessingCsv &&
            (!tableData || tableData.headers.length === 0) && (
              <div className="mt-2 text-xs text-gray-500 p-3 border border-dashed rounded-md flex items-center justify-center">
                <UploadCloud className="h-4 w-4 mr-2 text-gray-400" />
                <span>No CSV data loaded.</span>
              </div>
            )}
        </div>
      </>
    );
  };

  // Get property fields based on component type
  const renderPropertyFields = () => {
    switch (component.type) {
      case "Button":
        return (
          <>
            <div className="grid gap-2 mb-4">
              <Label htmlFor="button-text">Button Text</Label>
              <Input
                id="button-text"
                value={properties.text || "Button"}
                onChange={(e) => handleChange("text", e.target.value)}
              />
            </div>
            <div className="grid gap-2 mb-4">
              <Label htmlFor="button-variant">Variant</Label>
              <Select
                onValueChange={(value) => handleChange("variant", value)}
                value={properties.variant || "default"}
                defaultValue="default"
              >
                <SelectTrigger id="button-variant">
                  <SelectValue placeholder="Select a variant" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Default</SelectItem>
                  <SelectItem value="secondary">Secondary</SelectItem>
                  <SelectItem value="destructive">Destructive</SelectItem>
                  <SelectItem value="outline">Outline</SelectItem>
                  <SelectItem value="ghost">Ghost</SelectItem>
                  <SelectItem value="link">Link</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </>
        );
      case "Textarea":
        return (
          <>
            <div className="grid gap-2 mb-4">
              <Label htmlFor="textarea-placeholder">Placeholder</Label>
              <Input
                id="textarea-placeholder"
                value={properties.placeholder || "Textarea component"}
                onChange={(e) => handleChange("placeholder", e.target.value)}
              />
            </div>
            <div className="grid gap-2 mb-4">
              <Label htmlFor="textarea-rows">Rows</Label>
              <Input
                id="textarea-rows"
                type="number"
                value={properties.rows || 3}
                onChange={(e) =>
                  handleChange("rows", parseInt(e.target.value, 10))
                }
              />
            </div>
          </>
        );
      case "Input":
        return (
          <>
            <div className="grid gap-2 mb-4">
              <Label htmlFor="input-placeholder">Placeholder</Label>
              <Input
                id="input-placeholder"
                value={properties.placeholder || "Text input"}
                onChange={(e) => handleChange("placeholder", e.target.value)}
              />
            </div>
            <div className="grid gap-2 mb-4">
              <Label htmlFor="input-type">Type</Label>
              <Select
                onValueChange={(value) => handleChange("type", value)}
                value={properties.type || "text"}
                defaultValue="text"
              >
                <SelectTrigger id="input-type">
                  <SelectValue placeholder="Select input type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text">Text</SelectItem>
                  <SelectItem value="password">Password</SelectItem>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="number">Number</SelectItem>
                  <SelectItem value="tel">Telephone</SelectItem>
                  <SelectItem value="url">URL</SelectItem>
                  <SelectItem value="date">Date</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </>
        );
      case "Checkbox":
        return (
          <div className="grid gap-2 mb-4">
            <Label htmlFor="checkbox-label">Label</Label>
            <Input
              id="checkbox-label"
              value={properties.label || "Checkbox label"}
              onChange={(e) => handleChange("label", e.target.value)}
            />
          </div>
        );
      case "TextOutput":
        return (
          <>
            <div className="grid gap-2 mb-4">
              <Label htmlFor="textoutput-content">Placeholder</Label>
              <Input
                id="textoutput-content"
                value={properties.placeholder || "Output text will appear here"}
                onChange={(e) => handleChange("placeholder", e.target.value)}
              />
            </div>
            <div className="grid gap-2 mb-4">
              <Label htmlFor="textoutput-variant">Variant</Label>
              <Select
                onValueChange={(value) => handleChange("variant", value)}
                value={properties.variant || "default"}
                defaultValue="default"
              >
                <SelectTrigger id="textoutput-variant">
                  <SelectValue placeholder="Select a variant" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Default</SelectItem>
                  <SelectItem value="heading">Heading</SelectItem>
                  <SelectItem value="subheading">Subheading</SelectItem>
                  <SelectItem value="caption">Caption</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </>
        );
      case "DataTable":
        return renderTablePropertyFields();
      default:
        return (
          <div className="py-2 text-sm text-gray-500">
            No editable properties available for this component type.
          </div>
        );
    }
  };

  return (
    <PopoverContent className="w-80" onPointerDownOutside={onClose}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium">Edit Properties</h3>
        <Button size="sm" variant="ghost" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      {renderPropertyFields()}

      {renderNavigationControls()}

      <div className="flex justify-end mt-4">
        <Button onClick={handleSave} disabled={isProcessingCsv}>
          {isProcessingCsv ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            "Save Changes"
          )}
        </Button>
      </div>
    </PopoverContent>
  );
};
