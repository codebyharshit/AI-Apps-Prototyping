import React from "react";
import { cn } from "@/lib/utils";

type ShapeType = "rectangle" | "circle" | "triangle";

interface ShapeProps extends React.HTMLAttributes<HTMLDivElement> {
  type?: ShapeType;
  color?: string;
  borderColor?: string;
  borderWidth?: number;
  width?: number | string;
  height?: number | string;
  className?: string;
}

export function Shape({
  type = "rectangle",
  color = "bg-gray-200",
  borderColor = "border-gray-300",
  borderWidth = 1,
  width = "100%",
  height = "100%",
  className,
  ...props
}: ShapeProps) {
  let shapeClass = "";
  
  switch (type) {
    case "circle":
      shapeClass = "rounded-full";
      break;
    case "triangle":
      // Triangle is a special case using pseudo-elements
      shapeClass = "relative before:content-[''] before:absolute before:top-0 before:left-0 before:right-0 before:bottom-0 before:border-solid before:border-transparent before:border-b-current before:w-0 before:h-0 before:border-b-[100%] before:border-l-[50%] before:border-r-[50%] overflow-hidden";
      break;
    default: // rectangle
      shapeClass = "rounded-md";
  }

  return (
    <div
      className={cn(
        `${color} ${borderColor}`,
        `border-[${borderWidth}px]`,
        shapeClass,
        className
      )}
      style={{
        width: typeof width === "number" ? `${width}px` : width,
        height: typeof height === "number" ? `${height}px` : height,
      }}
      {...props}
    />
  );
} 