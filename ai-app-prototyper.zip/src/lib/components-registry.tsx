"use client";

import React from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { TextOutput } from "@/components/ui/textoutput";
import { ImageUpload } from "@/components/ui/imageupload";
import { DataTable } from "@/components/ui/datatable";
import { ComponentSize } from "./utils";
import { AIComponentRenderer } from "@/components/AIComponentRenderer";
import { InsuranceChat } from "@/components/ui/insurancechat";
import { InsuranceInsight } from "@/components/ui/insuranceinsight";
import { Icon } from "@/components/ui/icon";
import { Shape } from "@/components/ui/shape";
import { Alert } from "@/components/ui/alert";
import { Link } from "@/components/ui/link";
import { FileUploader } from "@/components/ui/fileuploader";
import { Searchbox } from "@/components/ui/searchbox";
import { Group } from "@/components/ui/group";
import { AlertCircle, Info, Mail } from "lucide-react";
import Chatbot from "@/components/ui/chatbot";
import PromptPlayground from "@/components/ui/promptplayground";
import InputVariantsPanel from "@/components/ui/inputvariantspanel";
import ResponseInspector from "@/components/ui/responseinspector";
import PersonaSwitcher from "@/components/ui/personaswitcher";
import CustomOutputRenderer from "@/components/ui/customoutputrenderer";
import { Card } from "@/components/ui/card";
import DebugComponent from "@/components/DebugComponent";

// Define the Component Registry type
export interface ComponentDefinition {
  type: string;
  label: string;
  category: string;
  icon?: React.ReactNode;
  defaultSize: ComponentSize;
  render: (props: any) => React.ReactNode;
}

// Create the registry of available components
export const componentsRegistry: ComponentDefinition[] = [
  {
    type: "Textarea",
    label: "Text Area",
    category: "Input",
    defaultSize: {
      width: 256,
      height: 80,
    },
    render: (props) => {
      return (
        <Textarea
          id={props.id || "text-area"}
          placeholder={props.placeholder || "Textarea component"}
          className={`${props.className || ""} ${
            !props.isInteractive ? "pointer-events-none" : ""
          }`}
          disabled={!props.isInteractive}
          rows={props.rows || 3}
          onChange={props.onChange}
          value={props.value}
        />
      );
    },
  },
  {
    type: "Button",
    label: "Button",
    category: "Input",
    defaultSize: {
      width: 80,
      height: 40,
    },
    render: (props) => {
      return (
        <Button
          id={props.id || "button"}
          className={`${props.className || ""} ${
            !props.isInteractive ? "pointer-events-none" : ""
          }`}
          onClick={!props.isInteractive ? (e) => e.preventDefault() : undefined}
          variant={props.variant || "default"}
        >
          {props.text || "Button"}
        </Button>
      );
    },
  },
  {
    type: "Input",
    label: "Text Input",
    category: "Input",
    defaultSize: {
      width: 256,
      height: 40,
    },
    render: (props) => {
      return (
        <Input
          id={props.id || "text-input"}
          placeholder={props.placeholder || "Text input"}
          className={`${props.className || ""} ${
            !props.isInteractive ? "pointer-events-none" : ""
          }`}
          disabled={!props.isInteractive}
          type={props.type || "text"}
          onChange={props.onChange}
          value={props.value}
        />
      );
    },
  },
  {
    type: "Checkbox",
    label: "Checkbox",
    category: "Input",
    defaultSize: {
      width: 192,
      height: 40,
    },
    render: (props) => {
      return (
        <div
          className={`flex items-center ${
            !props.isInteractive ? "pointer-events-none" : ""
          }`}
        >
          <div className="inline-flex items-center justify-center h-5 w-5 mr-2">
            <Checkbox
              id={props.id || "checkbox"}
              className="h-4 w-4"
              disabled={!props.isInteractive}
              onCheckedChange={props.onChange}
              checked={props.value}
            />
          </div>
          <Label
            htmlFor={props.id || "checkbox"}
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            {props.label || "Checkbox label"}
          </Label>
        </div>
      );
    },
  },
  {
    type: "ImageUpload",
    label: "Image Upload",
    category: "Input",
    defaultSize: {
      width: 256,
      height: 192,
    },
    render: (props) => {
      return (
        <ImageUpload
          id={props.id || "image-upload"}
          className={`${props.className || ""} ${
            !props.isInteractive ? "pointer-events-none" : ""
          }`}
          isInteractive={props.isInteractive}
          value={props.value}
          onChange={props.onChange}
        />
      );
    },
  },
  // Text Output component in Output category
  {
    type: "TextOutput",
    label: "Text Output",
    category: "Output",
    defaultSize: {
      width: 256,
      height: 80,
    },
    render: (props) => {
      return (
        <TextOutput
          id={props.id || "text-output"}
          className={`${props.className || ""} ${
            !props.isInteractive ? "pointer-events-none" : ""
          }`}
          placeholder={props.placeholder || "Output text will appear here"}
          content={props.content}
          variant={props.variant || "default"}
          maxLines={props.maxLines}
        />
      );
    },
  },
  // Data Display category
  {
    type: "DataTable",
    label: "Data Table",
    category: "Data Display",
    defaultSize: {
      width: 450,
      height: 300,
    },
    render: (props: any) => {
      return (
        <DataTable
          id={props.id}
          className={`${props.className || ""} ${
            !props.isInteractive ? "pointer-events-none cursor-default" : ""
          }`}
          data={props.data}
          onDataChange={props.onDataChange}
          isInteractive={props.isInteractive}
        />
      );
    },
  },
  {
    type: "Icon",
    label: "Icon",
    category: "Visual Elements",
    defaultSize: {
      width: 40,
      height: 40,
    },
    render: (props) => {
      const LucideIcon = props.iconName ? require("lucide-react")[props.iconName] || Mail : Mail;
      return (
        <Icon
          id={props.id || "icon"}
          className={props.className || ""}
          icon={LucideIcon}
          size={props.size || 24}
          strokeWidth={props.strokeWidth || 2}
        />
      );
    },
  },
  {
    type: "Shape",
    label: "Shape",
    category: "Visual Elements",
    defaultSize: {
      width: 100,
      height: 100,
    },
    render: (props) => {
      return (
        <Shape
          id={props.id || "shape"}
          className={props.className || ""}
          type={props.type || "rectangle"}
          color={props.color || "bg-gray-200"}
          borderColor={props.borderColor || "border-gray-300"}
          borderWidth={props.borderWidth || 1}
        />
      );
    },
  },
  {
    type: "Alert",
    label: "Alert",
    category: "Visual Elements",
    defaultSize: {
      width: 300,
      height: 80,
    },
    render: (props) => {
      return (
        <Alert
          id={props.id || "alert"}
          className={props.className || ""}
          variant={props.variant || "default"}
          title={props.title || "Alert Title"}
          icon={props.showIcon ? <AlertCircle className="h-4 w-4" /> : undefined}
        >
          {props.content || "This is an alert message."}
        </Alert>
      );
    },
  },
  {
    type: "Link",
    label: "Link",
    category: "Visual Elements",
    defaultSize: {
      width: 100,
      height: 40,
    },
    render: (props) => {
      return (
        <Link
          id={props.id || "link"}
          className={`${props.className || ""} ${!props.isInteractive ? "pointer-events-none" : ""}`}
          variant={props.variant || "default"}
          size={props.size || "default"}
          href={props.href || "#"}
          target={props.target}
          asButton={props.asButton}
          onClick={!props.isInteractive ? (e) => e.preventDefault() : undefined}
        >
          {props.text || "Link Text"}
        </Link>
      );
    },
  },
  {
    type: "Searchbox",
    label: "Searchbox",
    category: "Input",
    defaultSize: {
      width: 256,
      height: 40,
    },
    render: (props) => {
      return (
        <Searchbox
          id={props.id || "searchbox"}
          className={`${props.className || ""} ${!props.isInteractive ? "pointer-events-none" : ""}`}
          placeholder={props.placeholder || "Search..."}
          iconPosition={props.iconPosition || "left"}
          clearable={props.clearable || true}
          disabled={!props.isInteractive}
          onSearch={props.onSearch}
          onChange={props.onChange}
          value={props.value}
        />
      );
    },
  },
  {
    type: "Group",
    label: "Group",
    category: "Containers",
    defaultSize: {
      width: 300,
      height: 200,
    },
    render: (props) => {
      return (
        <Group
          id={props.id || "group"}
          className={props.className || ""}
          direction={props.direction || "row"}
          align={props.align || "start"}
          justify={props.justify || "start"}
          spacing={props.spacing || "md"}
          wrap={props.wrap || false}
          bordered={props.bordered || false}
        >
          {props.children || <div className="text-gray-400 text-sm p-4">Add components here</div>}
        </Group>
      );
    },
  },
  {
    type: "FileUploader",
    label: "File Uploader",
    category: "Input",
    defaultSize: {
      width: 400,
      height: 200,
    },
    render: (props) => {
      return (
        <FileUploader
          id={props.id || "file-uploader"}
          className={`${props.className || ""} ${!props.isInteractive ? "pointer-events-none" : ""}`}
          multiple={props.multiple || false}
          accept={props.accept}
          maxSize={props.maxSize}
          dropzoneText={props.dropzoneText || "Drag and drop files here, or click to select files"}
          buttonText={props.buttonText || "Select Files"}
          showFileList={props.showFileList || true}
          disabled={!props.isInteractive}
          onChange={props.onChange}
          value={props.value}
        />
      );
    },
  },
  {
    type: "Card",
    label: "Card",
    category: "Containers",
    defaultSize: {
      width: 300,
      height: 200,
    },
    render: (props) => {
      return (
        <Card
          id={props.id || "card"}
          className={`${props.className || ""} p-4 ${
            !props.isInteractive ? "pointer-events-none" : ""
          }`}
        >
          <div className="space-y-2">
            {props.title && (
              <div className="text-lg font-semibold">{props.title}</div>
            )}
            {props.content && (
              <div className="text-sm text-gray-600">{props.content}</div>
            )}
          </div>
        </Card>
      );
    },
  },
  {
    type: "DebugComponent",
    label: "Debug Component",
    category: "Debug",
    defaultSize: {
      width: 300,
      height: 200,
    },
    render: (props) => <DebugComponent />,
  },
  {
    type: "Chatbot",
    label: "Chatbot",
    category: "AI Simulation",
    defaultSize: {
      width: 400,
      height: 500,
    },
    render: (props) => <Chatbot {...props} />,
  },
  {
    type: "SimulationChatbot",
    label: "Simulation Chatbot",
    category: "AI Simulation",
    icon: null,
    defaultSize: {
      width: 400,
      height: 500,
    },
    render: (props) => <Chatbot {...props} />,
  },
  {
    type: "PromptPlayground",
    label: "Prompt Playground",
    category: "AI Tools",
    icon: null,
    defaultSize: {
      width: 400,
      height: 400,
    },
    render: (props) => <PromptPlayground {...props} />,
  },
  {
    type: "InputVariantsPanel",
    label: "Input Variants Panel",
    category: "AI Tools",
    icon: null,
    defaultSize: {
      width: 400,
      height: 400,
    },
    render: (props) => <InputVariantsPanel {...props} />,
  },
  {
    type: "ResponseInspector",
    label: "Response Inspector",
    category: "AI Tools",
    icon: null,
    defaultSize: {
      width: 400,
      height: 400,
    },
    render: (props) => <ResponseInspector {...props} />,
  },
  {
    type: "PersonaSwitcher",
    label: "Persona/Style Switcher",
    category: "AI Tools",
    icon: null,
    defaultSize: {
      width: 400,
      height: 400,
    },
    render: (props) => <PersonaSwitcher {...props} />,
  },
  {
    type: "CustomOutputRenderer",
    label: "Custom Output Renderer",
    category: "AI Tools",
    icon: null,
    defaultSize: {
      width: 400,
      height: 400,
    },
    render: (props) => <CustomOutputRenderer {...props} />,
  },
];

// Hidden AI component definitions (not shown in sidebar but used by the app)
const aiComponentsRegistry: ComponentDefinition[] = [
  // AI Input component
  {
    type: "AIInput",
    label: "AI Input",
    category: "AI",
    defaultSize: {
      width: 300,
      height: 200,
    },
    render: (props) => {
      return <AIComponentRenderer component={props.component} {...props} />;
    },
  },
  // AI Output component
  {
    type: "AIOutput",
    label: "AI Output",
    category: "AI",
    defaultSize: {
      width: 300,
      height: 200,
    },
    render: (props) => {
      return <AIComponentRenderer component={props.component} {...props} />;
    },
  },
  // AI Form component
  {
    type: "AIForm",
    label: "AI Form",
    category: "AI",
    defaultSize: {
      width: 400,
      height: 300,
    },
    render: (props) => {
      return <AIComponentRenderer component={props.component} {...props} />;
    },
  },
  // AI Container component
  {
    type: "AIContainer",
    label: "AI Container",
    category: "AI",
    defaultSize: {
      width: 400,
      height: 300,
    },
    render: (props) => {
      return <AIComponentRenderer component={props.component} {...props} />;
    },
  },
  // AI Display component
  {
    type: "AIDisplay",
    label: "AI Display",
    category: "AI",
    defaultSize: {
      width: 300,
      height: 200,
    },
    render: (props) => {
      return <AIComponentRenderer component={props.component} {...props} />;
    },
  },
  // AI UI Component (for HTML-to-React conversions)
  {
    type: "AIUIComponent",
    label: "AI UI Component",
    category: "AI",
    defaultSize: {
      width: 400,
      height: 300,
    },
    render: (props) => {
      return <AIComponentRenderer component={props.component} {...props} />;
    },
  },
];

// Insurance specific components
const insuranceComponentsRegistry: ComponentDefinition[] = [
  {
    type: "InsuranceChat",
    label: "Insurance Chat",
    category: "Output",
    defaultSize: {
      width: 300,
      height: 400,
    },
    render: (props) => {
      return (
        <InsuranceChat
          id={props.id || "insurance-chat"}
          className={props.className}
          isInteractive={props.isInteractive}
          initialMessage="Hello! I'm your Insurance Assistant. How can I help you today?"
        />
      );
    },
  },
  {
    type: "InsuranceInsight",
    label: "Insurance Insight",
    category: "Input",
    defaultSize: {
      width: 400,
      height: 500,
    },
    render: (props) => {
      return (
        <InsuranceInsight
          id={props.id || "insurance-insight"}
          className={props.className}
          isInteractive={props.isInteractive}
        />
      );
    },
  },
  {
    type: "InsuranceInput",
    label: "Insurance Input",
    category: "Input",
    defaultSize: {
      width: 300,
      height: 50,
    },
    render: (props) => {
      return <AIComponentRenderer component={props.component} {...props} />;
    },
  },
  {
    type: "InsuranceSendButton",
    label: "Insurance Send Button",
    category: "Button",
    defaultSize: {
      width: 80,
      height: 40,
    },
    render: (props) => {
      return <AIComponentRenderer component={props.component} {...props} />;
    },
  },
];

// Helper function to get a component definition by type
export const getComponentDefinition = (
  type: string
): ComponentDefinition | undefined => {
  // First check for exact match in standard registry
  const exactMatch = componentsRegistry.find((component) => component.type === type);
  if (exactMatch) return exactMatch;

  // Then check in the AI components registry
  const aiMatch = aiComponentsRegistry.find((component) => component.type === type);
  if (aiMatch) return aiMatch;
  
  // Then check in the insurance components registry
  const insuranceMatch = insuranceComponentsRegistry.find((component) => component.type === type);
  if (insuranceMatch) return insuranceMatch;

  // If no exact match, try to match AI prefixed components with their base definitions
  if (type.startsWith("AI")) {
    // First try exact match in AI registry
    const aiExactMatch = aiComponentsRegistry.find(
      (component) => component.type === type
    );
    if (aiExactMatch) return aiExactMatch;
    
    // Then try to match with base definitions
    const aiType = type.replace(/^AI/, "");
    const aiComponentDef = aiComponentsRegistry.find(
      (component) => component.type === `AI${aiType}`
    );
    if (aiComponentDef) return aiComponentDef;
    
    // If still no match, create a generic AI component definition
    return {
      type: type,
      label: type,
      category: "AI",
      defaultSize: {
        width: 400,
        height: 300,
      },
      render: (props) => {
        return <AIComponentRenderer component={props.component} {...props} />;
      },
    };
  }

  return undefined;
};
