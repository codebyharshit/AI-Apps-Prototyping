import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Interface for component positioning data
export interface ComponentPosition {
  x: number;
  y: number;
}

// Interface for component size in px
export interface ComponentSize {
  width: number;
  height: number;
}

// Interface for component data used in the Canvas
export interface ComponentData {
  id: string;
  type: string;
  position: ComponentPosition;
  size: ComponentSize;
  frameId?: string;
  properties?: Record<string, any>;
  aiConfig?: {
    role?: "input" | "output" | "both" | null;
    promptTemplate?: string;
    outputMapping?: Record<string, string>;
  };
}

// Interface for frame component
export interface FrameData {
  id: string;
  position: ComponentPosition;
  size: ComponentSize;
  label?: string;
}

// For AI functionality later
export interface AIComponentConfig {
  componentId: string;
  role: "input" | "output" | "both";
  settings: Record<string, any>;
}

/**
 * Applies style overrides to a component's props
 * This function merges style overrides from direct manipulation into component props
 */
export function applyStyleOverrides(props: any, styleOverrides: Record<string, any>): any {
  if (!styleOverrides || Object.keys(styleOverrides).length === 0) {
    return props;
  }

  // Create a new props object with merged styles
  const updatedProps = { ...props };
  
  // If there's already a style prop, merge with it
  if (updatedProps.style) {
    updatedProps.style = {
      ...updatedProps.style,
      ...styleOverrides
    };
  } else {
    // Otherwise, create a new style prop
    updatedProps.style = styleOverrides;
  }

  return updatedProps;
}

/**
 * Applies content changes from direct manipulation to component props
 */
export function applyContentChanges(props: any, contentChanges: Record<string, any>): any {
  if (!contentChanges || Object.keys(contentChanges).length === 0) {
    return props;
  }

  const updatedProps = { ...props };
  
  // Apply text content changes
  if (contentChanges.textContent) {
    updatedProps.content = contentChanges.textContent;
  }
  
  // Apply placeholder changes
  if (contentChanges.placeholder) {
    updatedProps.placeholder = contentChanges.placeholder;
  }

  return updatedProps;
}
